import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  rutaBase: string = 'https://fer-sepulveda.cl/API_CLASE/api-service.php'



  constructor(private http: HttpClient) { }

  PersonaAlmacenar(correo, contrasena, nombre, apellido) {
    let that = this;

    return new Promise(resolve => {
      resolve(that.http.post(that.rutaBase, {
        nombreFuncion: "PersonaAlmacenar",
        parametros: [correo, contrasena, nombre, apellido]
      }).toPromise())
    })
  }

  PersonaListar() {
    let that = this;

    return new Promise(resolve => {
      resolve(that.http.get(that.rutaBase 
        + '?nombreFuncion=PersonaListar').toPromise())
    })
  }

  login(correo, password) {
    let that = this;

    return new Promise(resolve => {
      resolve(that.http.post(that.rutaBase, {
        nombreFuncion: "login",
        parametros: [correo, password]
      }).toPromise())
    })
  }




















}


