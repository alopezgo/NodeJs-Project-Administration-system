import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { LoadingController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-listar',
  templateUrl: './listar.page.html',
  styleUrls: ['./listar.page.scss'],
})
export class ListarPage implements OnInit {

  lista_personas = [];
  mdl_correo: string;
  mdl_pasword: string;

  lista_usuario = []


  constructor(private api: ApiService, 
    private loadingController: LoadingController, router:Router) { }

  ngOnInit() {
    this.listar();

    this.loadingController.create({
      message: 'Obteniendo información...',
      spinner: 'lines-sharp'
    }).then(res => {
      res.dismiss()
    })
  }

  async listar() {
    let that = this;
    this.loadingController.create({
      message: 'Obteniendo información...',
      spinner: 'lines-sharp'
    }).then(async res => {
      res.present();

      let data = await that.api.PersonaListar();
      that.lista_personas = data['result'];
      console.log(data)

      res.dismiss();
    })

    
  }



  

}
