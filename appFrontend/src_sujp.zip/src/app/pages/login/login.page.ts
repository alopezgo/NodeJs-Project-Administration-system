import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoadingController, ToastController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {


<<<<<<< HEAD
  mdl_correo = "user"
  mdl_password: "1234";
  mdl_nombre: string;
  mdl_apellido: string;






  constructor(private router:Router, private api: ApiService, private loadingController: LoadingController, private toastController: ToastController) { }
=======
  constructor() { }
>>>>>>> 4bbe7846075211a0fcbc034863bb9a6df14e92e1

  ngOnInit() {
    this.loadingController.create({
      message: '',
      spinner: 'lines-sharp'
    }).then(res => {
      res.dismiss()
    })


  }


  
  async login() {
    let that = this;
    this.loadingController.create({
      message: 'Buscando Persona',
      spinner: 'lines-sharp'
    }).then(async res => {
      res.present();

      let data = await that.api.login(
        that.mdl_correo, that.mdl_password);

      if (data['email'] === this.mdl_correo && data['password'] === this.mdl_password) {
        that.mostrarMensaje('Credenciales validadas');
        this.router.navigate(['principal']);
      } else {
        that.mostrarMensaje('Error');
        console.log('datos no coinciden')
      }

      res.dismiss();
    })
    
  }



  async mostrarMensaje(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000,
      position: 'bottom'
    });

    await toast.present();
  }

}











  






















